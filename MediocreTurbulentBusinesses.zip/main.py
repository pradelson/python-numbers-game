

num1 = int(input("numero de jugador1: "))
num2 = int(input("numero de jugador2: "))

if num1>num2:
  num1*=2
  print(f" el numero mayor es {num1}, gano jugador 1")
  

elif num2>num1:
  num2*=2 
  print(f" el numero mayor es {num2}, gano jugador 2") 


while num1==num2:
  raise TypeError("es un empate uno tiene que ganar") 
  
  


 










     

